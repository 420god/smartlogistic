package com.douzone.smartlogistics.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RVISCountVo {
	private Long RVCount;
	private Long ISCount;
}
