import React from 'react';

const AdminMain = () => {
    return (
        <div>
            AdminMain 페이지입니다.
        </div>
    );
};

export default AdminMain;