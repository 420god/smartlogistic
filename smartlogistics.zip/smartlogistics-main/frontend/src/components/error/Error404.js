import React from "react";

export default function Gallery() {
  return (
    <div>
      <h2
        style={{
          lineHeight: "200px",
          textAlign: "center",
        }}
      >
        Whoops - 404 Not Found
      </h2>
    </div>
  );
}
